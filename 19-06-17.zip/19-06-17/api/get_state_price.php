<?php
$servername = "localhost";
$username = "bswmolcz_fuel";
$password = "fuel@123";
$dbname = "bswmolcz_fuelprice";
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);

	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
	//echo "Connected successfully";
	$searchKeyword = $_GET["state"];
	$linitUser = $_REQUEST["limit"];
	$limitStart = $linitUser * 10;
	//$limitStart = $limitEnd-10;
	
	if($_GET["state"]){
		$sql = "select * from all_state_price WHERE state LIKE  '%".$searchKeyword."%' ORDER BY id ASC";
		
		$getStateprice = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));

		//create an array
		$response = array();
		while($row =mysqli_fetch_assoc($getStateprice))
		{
			$response[] = $row;
		}
		echo json_encode($response);

		//close the db connection
		
	$conn->close();
	}
?>
