<?php
//include('session.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Fuel Price | Admin</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	
	
	<style>
		.input_set{display:none;}
		h3{
			text-align: center;
			color: #25d025;
		}
	</style>
	<script type="text/javascript">
		/* $(document).ready(function(){
			$('.edita').click(function(){
				var id = this.id;
				//alert(id);
				$("#" + id).removeAttr('disabled');
				$("#" + id).removeAttr('disabled');
			})
		}) */
	</script>
</head>
<body>
<?php
$servername = "localhost";
$username = "bswmolcz_fuel";
$password = "fuel@123";
$dbname = "bswmolcz_fuelprice";
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);

	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
	//echo "Connected successfully";
?>
<div class="container">
  <h2>Fuel Price's in all state of India</h2><!--<a href="logout.php">logout</a>-->
  <?php 
		$msg = "";
		$msg = $_GET['msg'];
		if($msg == 'a'){
			echo "<h3>Price Updated Successfully</h3>";
		}
  ?>
  <form action="import_file.php" method="post" enctype="multipart/form-data">
  <input type="file" name="file"><input type="submit" name="save" value="upload">
  </form>
  <!--<p>The .table-hover class enables a hover state on table rows:</p>   -->         
  <table class="table table-hover">
    <thead>
      <tr>
        <th>State</th>
        <th>Petrol Price</th>
        <th>Diesel Price</th>
		<th>Date </th>
		<th>Action </th>
      </tr>
    </thead>
    <tbody>
	<?php
	$sql = "select * from all_state_price";
	$getStateprice = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));
	while($row =mysqli_fetch_assoc($getStateprice))
		{
	?>
      <tr>
        <td><?php echo $row['state'];?></td>
        <td><?php echo $row['petrol_price'];?>
		<!--<input type="text" name="petrol_pr" id="<?php echo $row['id'];?>" value="<?php echo $row['petrol_price'];?>" class="petrol_pr" disabled />-->
		</td>
        <td><?php echo $row['diesel_price'];?>
		<!--<input type="text" name="petrol_pr" id="<?php echo $row['id'];?>" value="<?php echo $row['diesel_price'];?>" class="petrol_pr" disabled />-->
		</td>
		<td><?php echo $row['update_on'];?></td>
		<td><a href="edit_price.php?id=<?php echo $row['id'];?>">Edit</a></td>
      </tr>
      <?php
		}?>
    </tbody>
  </table>
</div>

</body>
</html>
