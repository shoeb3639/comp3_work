<?php
	session_start();
	date_default_timezone_set("Asia/Kolkata");
	$servername = "localhost";
	$username = "bswmolcz_fuel";
	$password = "fuel@123";
	$dbname = "bswmolcz_fuelprice";
		// Create connection
		$conn = new mysqli($servername, $username, $password, $dbname);

		// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		} 
		//echo "Connected successfully";
	if(isset($_POST)){
		//print_r($_POST);
		$username = $_POST['username'];
		$password = $_POST['password'];
		if($username == "" && $password == ""){
			echo "Please enter your username and password";exit;
		}
		
		$date		  = date("Y-m-d h:i:s");
		$sql = "SELECT * FROM admin_login WHERE username='".$username."' AND password='".$password."'";
		if (mysqli_query($conn, $sql)) {
			//$_SESSION['login_user']= $username; 
			echo "1";
		} else {
			echo "Incorrect Username or Password";
		}

		mysqli_close($conn);
	}
?>