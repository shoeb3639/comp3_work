
<!DOCTYPE html>
<html lang="en">
<head>
	<title>Bootstrap Example</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	
	
	<style>
		.input_set{display:none;}
	</style>
	<script type="text/javascript">
		$(document).ready(function(){
			$('.update').click(function(){
				var id = this.id;
				var petrolPrice = $("#petrolPrice").val();
				var dieselPrice = $("#dieselPrice").val();
				var dataString = 'id='+id+'&petrolPrice='+petrolPrice+'&dieselPrice='+dieselPrice;
				//alert(dataString);
				$.ajax({
					type:'post',
					url:'update_price.php',
					data:dataString,
					success:function(data){
						if(data == 1){
							window.location.href="http://bswmobility.com/fuelprice/admin/dashboard.php?msg=a"
						}else{
							$('.errmsg').html(data);
						}
					}
				})
			})
		})
	</script>
</head>
<body>
<?php
$servername = "localhost";
$username = "bswmolcz_fuel";
$password = "fuel@123";
$dbname = "bswmolcz_fuelprice";
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);

	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
	//echo "Connected successfully";
?>
<div class="container">
  <h2>Fuel Price's in all state of India</h2>
  <div class="errmsg"></div>
  <!--<p>The .table-hover class enables a hover state on table rows:</p>   -->         
  <table class="table table-hover">
    <thead>
      <tr>
        <th>State</th>
        <th>Petrol Price</th>
        <th>Diesel Price</th>
		<th>Date </th>
		<th>Action </th>
      </tr>
    </thead>
    <tbody>
	<?php
	//date_default_timezone_set("Asia/Kolkata");
	$id = $_GET['id'];
	//echo date("Y-m-d h:i:s");
	
	$sql = "select * from all_state_price where id ='$id' limit 1";
	$getStateprice = mysqli_query($conn, $sql) or die("Error in Selecting " . mysqli_error($conn));
	while($row =mysqli_fetch_assoc($getStateprice))
		{
	?>
      <tr>
        <td><?php echo $row['state'];?></td>
        <td><input type="text" id="petrolPrice" value="<?php echo $row['petrol_price'];?>"></td>
        <td><input type="text" id="dieselPrice" value="<?php echo $row['diesel_price'];?>"></td>
		<td><?php echo $row['update_on'];?></td>
		<input type="hidden" id="stateid" value="<?php echo $row['id'];?>">
		<td><a href="javascript:void(0)" class="update" id="<?php echo $row['id'];?>">Update</a></td>
      </tr>
      <?php
		}?>
    </tbody>
  </table>
</div>

</body>
</html>
