<?php
	date_default_timezone_set("Asia/Kolkata");
	
	$servername = "localhost";
	$username = "bswmolcz_fuel";
	$password = "fuel@123";
	$dbname = "bswmolcz_fuelprice";
		// Create connection
		$conn = new mysqli($servername, $username, $password, $dbname);

		// Check connection
		if ($conn->connect_error) {
			die("Connection failed: " . $conn->connect_error);
		} 
		//echo "Connected successfully";
	if(isset($_POST)){
		//print_r($_POST);
		$id 		  = $_POST['id'];
		$petrol_price = $_POST['petrolPrice'];
		$diesel_price = $_POST['dieselPrice'];
		$date		  = date("Y-m-d h:i:s");
		$sql = "UPDATE all_state_price SET petrol_price = '".$petrol_price."' , diesel_price ='".$diesel_price."' , update_on = '".$date."' WHERE id = '$id' ";
		if (mysqli_query($conn, $sql)) {
			echo "1";
		} else {
			echo "Error updating record: " . mysqli_error($conn);
		}

		mysqli_close($conn);
	}
?>