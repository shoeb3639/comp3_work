<?php
$servername = "localhost";
$username = "bswmolcz_fuel";
$password = "fuel@123";
$dbname = "bswmolcz_fuelprice";
	// Create connection
	$conn = new mysqli($servername, $username, $password, $dbname);

	// Check connection
	if ($conn->connect_error) {
		die("Connection failed: " . $conn->connect_error);
	} 
	//echo "Connected successfully";
	if(isset($_POST["save"])){
		
		//Get the already save price of fuel
		$get_exist_price = mysqli_query($conn,"SELECT id,petrol_price,diesel_price,update_on FROM fuelprice_bk");
		while($result = mysqli_fetch_array($get_exist_price)){
			$saveRecord = "INSERT INTO old_fuel_price state_id ='".$result['id']."', old_petrol_price ='".$result['petrol_price']."', old_diesel_price ='".$result['diesel_price']."', update_date ='".$result['update_on']."'";
			if (mysqli_query($conn, $saveRecord)) {
							//echo "Data updated";
			} else {
				echo "Error updating record: " . mysqli_error($conn);
			}
		}
		/* date_default_timezone_set("Asia/Kolkata");
		//Import the PHPExcel reader File
        include_once('ExcelReader/Excel/reader.php');
		
		$destination = realpath('files') . '/';
		$fileName    = date('Ymdh') . "_" . $_FILES['file']['name'];
		move_uploaded_file($_FILES['file']['tmp_name'], $destination . $fileName);
		$file = $destination . $fileName;
		
		chmod($file, 0777);
		
			//Create an object for the Class
			$data = new Spreadsheet_Excel_Reader();
			//Set the output Encoding
			$data->setOutputEncoding('CP1251');
			//Read the data of the file posted
			$data->read($file); //echo "hi";die;
			//echo "<pre>";print_r($data);die;
			$cntNo = count($data->sheets[0]["cells"]);
			$cnt   = $cntNo + $cntNo;
			
			//print_r($data->sheets[0]);die;
			if (!empty($data)) {
				for ($x = 2; $x <= $cnt; $x++) {
					$saveRecords = array();
					//	echo "<pre>";
					
					
					if (isset($data->sheets[0]["cells"][$x])) {
						$data_array = array();
						$data_array = $data->sheets[0]["cells"][$x];
						//pr($data_array);
						$capital       	= trim(isset($data_array[1]) ? $data_array[1] : "");
						$state     		= trim(isset($data_array[2]) ? $data_array[2] : "");
						$petrol_pr      = isset($data_array[3]) ? $data_array[3] : "";
						$diesel_pr     	= isset($data_array[4]) ? $data_array[4] : "";
						$updated		= date("Y-m-d h:i:s");
						
						$sql = "UPDATE fuelprice_bk SET petrol_price='".$petrol_pr."',diesel_price='".$diesel_pr."',update_on='".$updated."' WHERE state LIKE '%$state%'";
						if (mysqli_query($conn, $sql)) {
							//echo "Data updated";
						} else {
							echo "Error updating record: " . mysqli_error($conn);
						}
					}
					
				}
				header('Location: dashboard.php');
			} 
			 */
		
	}
?>